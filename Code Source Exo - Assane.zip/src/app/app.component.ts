import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  Array = [
    {
      title: 'Mon premier post',
      content: 'Voici mon premier post. Merci de like si vous aimez ! :-)',
      score: 0
    },
    {
      title: 'Mon deuxième post',
      content: 'Voici mon deuxième post. Merci de like si vous aimez ! :-)',
      score: 0
    },
    {
      title: 'Mon troisième post',
      content: 'Voici mon troisième post. Merci de like si vous aimez ! :-)',
      score: 0
    }
  ];
  constructor() {
  }
}
